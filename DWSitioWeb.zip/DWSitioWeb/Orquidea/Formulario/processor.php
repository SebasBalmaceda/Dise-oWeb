<?php

$where_form_is="http://".$_SERVER['SERVER_NAME'].strrev(strstr(strrev($_SERVER['PHP_SELF']),"/"));

mail("contacto@orquidea.com.ar","phpFormGenerator - Form submission","Form data:

Nombre: " . $_POST['field_1'] . " 
E-mail: " . $_POST['field_2'] . " 
Mensaje: " . $_POST['field_3'] . " 


 powered by phpFormGenerator.
");

include("confirm.html");

?>