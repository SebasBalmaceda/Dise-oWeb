vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 May 2018 06:47:00 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|Sebas-PC\\Sebas
vti_modifiedby:SR|Sebas-PC\\Sebas
vti_timecreated:TR|20 May 2018 06:47:00 -0000
vti_cacheddtm:TX|20 May 2018 06:47:00 -0000
vti_filesize:IR|4635
vti_cachedtitle:SR| - created by phpFormGenerator
vti_cachedbodystyle:SR|<body onLoad="collapseAll()">
vti_cachedlinkinfo:VX|Q|style.css Q|calendar/calendar-blue2.css S|calendar/calendar.js S|calendar/calendar-en.js S|calendar/calendar-setup.js H|http://phpformgen.sourceforge.net
vti_cachedsvcrellinks:VX|FQUS|Formulario/style.css FQUS|Formulario/calendar/calendar-blue2.css FSUS|Formulario/calendar/calendar.js FSUS|Formulario/calendar/calendar-en.js FSUS|Formulario/calendar/calendar-setup.js NHHS|http://phpformgen.sourceforge.net
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=content-type text/html;\\ charset=UTF-8
vti_charset:SR|utf-8
vti_title:SR| - created by phpFormGenerator
vti_backlinkinfo:VX|
